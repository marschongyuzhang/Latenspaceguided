function newArray = keepvalue(input)
%keep th value 
desiredSize = 27; 
persistent lastArray;

if isempty(lastArray)
    lastArray = 1.5/1.75*[[0, 0, 0]'; [2.88, -110.70, 71.37]'; [0.72, -167.35, -149.86]'; [2.16, 56.65, -205.24]'; 185.533188909302;-49.4957907046416;21.3858814388855;225.458966831772;-11.6642712246303;-333.763934105475;182.134258521384;102.443984323365;-558.156016953349;235.744326507093;143.511633141893;-547.799198400523;199.994404526046;152.083274537368;-637.925844033496];
end

currentSize = numel(input);
if currentSize < desiredSize
    newArray = lastArray;
    lastArray = input;
elseif currentSize == desiredSize
    newArray = input;
    lastArray = newArray;
else 
    error('Current size is larger than the desired size.')
end

end
