%%%%%%%%%%%%%%%%%%%%%%%%% ConstructSfunParameters.m %%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% ConstructSfunParameters: Generate the parameters of the Sfunction for the 
%		Vicon block thanks to the mask parmaters.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Author: Augustin Manecy
%
% Copyright (C) 2011-2014 Augustin Manecy
%
% augustin.manecy@gmail.com
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This file is part of RT-MaG Toolbox.
%
%   RT-MaG Toolbox is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as published by
%   the Free Software Foundation, either version 3 of the License, or
%   (at your option) any later version.
%
%   RT-MaG Toolbox is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public License
%   along with RT-MaG Toolbox.  If not, see <http://www.gnu.org/licenses/>.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This version of GPL is at https://www.gnu.org/licenses/gpl-3.0.txt
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [IP, Port, SampleTime, ObjectTab, UnlabeledMarker, ObjectName, SegmentName, MarkerName] = ConstructSfunParameters(ViconStructure)

    IP          = ['''' ViconStructure.IP ''''];
    Port        = num2str(ViconStructure.Port);
    SampleTime  = num2str(ViconStructure.SampleTime);
    
    if isfield(ViconStructure, 'Object')
        NbObject = length(ViconStructure.Object);
    else
        NbObject = 0;
        ObjectTab = [];
    end
    NbSegment   = 0;
    NbMarker    = 0;
    
    ObjectName  = '';
    SegmentName = '';
    MarkerName  = '';
    
    % DispStruct(ViconStructure)
    
    for i=1:1:NbObject
        % ObjectTab
        ObjectTab(i,1) = ViconStructure.Object(i).NbSegment;
        ObjectTab(i,2) = ViconStructure.Object(i).NbMarker;
        %ObjectName
        if isempty(ObjectName)
            ObjectName = ['''' ViconStructure.Object(i).Name];
        else
            ObjectName = [ObjectName ',' ViconStructure.Object(i).Name];
        end
        %SegmentName
        for j=1:1:ViconStructure.Object(i).NbSegment
            NbSegment = NbSegment+1;
             if isempty(SegmentName)
                SegmentName = ['''' ViconStructure.Object(i).Segment(j).Name];
             else
                SegmentName = [SegmentName ',' ViconStructure.Object(i).Segment(j).Name];
             end
        end
        %MarkerName
        for j=1:1:ViconStructure.Object(i).NbMarker
            NbMarker = NbMarker+1;
            if isempty(MarkerName)
                MarkerName = ['''' ViconStructure.Object(i).Marker(j).Name];
            else
                MarkerName = [MarkerName ',' ViconStructure.Object(i).Marker(j).Name];
            end
        end
    end
    % convert into string
    ObjectTab = mat2str(ObjectTab);
    if isempty(ObjectName)
        ObjectName = ['''' ''''];
    else
        ObjectName = [ObjectName ''''];
    end
    if isempty(SegmentName)
        SegmentName = ['''' ''''];
    else
        SegmentName = [SegmentName ''''];
    end
    if isempty(MarkerName)
        MarkerName = ['''' ''''];
    else
        MarkerName = [MarkerName ''''];
    end
    UnlabeledMarker = mat2str(ViconStructure.UnlabeledMarker);

end
