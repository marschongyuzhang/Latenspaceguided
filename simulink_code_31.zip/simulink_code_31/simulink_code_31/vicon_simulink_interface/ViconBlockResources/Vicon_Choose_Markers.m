function varargout = Vicon_Choose_Markers(varargin)
% VICON_CHOOSE_MARKERS MATLAB code for Vicon_Choose_Markers.fig
%      VICON_CHOOSE_MARKERS, by itself, creates a new VICON_CHOOSE_MARKERS or raises the existing
%      singleton*.
%
%      H = VICON_CHOOSE_MARKERS returns the handle to a new VICON_CHOOSE_MARKERS or the handle to
%      the existing singleton*.
%
%      VICON_CHOOSE_MARKERS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in VICON_CHOOSE_MARKERS.M with the given input arguments.
%
%      VICON_CHOOSE_MARKERS('Property','Value',...) creates a new VICON_CHOOSE_MARKERS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Vicon_Choose_Markers_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Vicon_Choose_Markers_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Vicon_Choose_Markers

% Last Modified by GUIDE v2.5 18-Jun-2013 16:42:04

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Vicon_Choose_Markers_OpeningFcn, ...
                   'gui_OutputFcn',  @Vicon_Choose_Markers_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Vicon_Choose_Markers is made visible.
function Vicon_Choose_Markers_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Vicon_Choose_Markers (see VARARGIN)

% Choose default command line output for Vicon_Choose_Markers
handles.output = hObject;

Marker_List = varargin{1};
set(handles.PossibleMarkerList, 'String', Marker_List);

handles.MenuViconHandles = varargin{2};

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Vicon_Choose_Markers wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Vicon_Choose_Markers_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in PossibleMarkerList.
function PossibleMarkerList_Callback(hObject, eventdata, handles)
% hObject    handle to PossibleMarkerList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

contents = cellstr(get(hObject,'String')) %returns listbox2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from PossibleMarkerList


% --- Executes during object creation, after setting all properties.
function PossibleMarkerList_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PossibleMarkerList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in WishedMarkerList.
function WishedMarkerList_Callback(hObject, eventdata, handles)
% hObject    handle to WishedMarkerList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns WishedMarkerList contents as cell array
%        contents{get(hObject,'Value')} returns selected item from WishedMarkerList


% --- Executes during object creation, after setting all properties.
function WishedMarkerList_CreateFcn(hObject, eventdata, handles)
% hObject    handle to WishedMarkerList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


% --- Executes on button press in Add_SelectedMarker.
function Add_SelectedMarker_Callback(hObject, eventdata, handles)
% hObject    handle to Add_SelectedMarker (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    % Get current parameters
    Selected_Marker        = get(handles.PossibleMarkerList,'Value');
    Possible_Marker_List	= get(handles.PossibleMarkerList, 'String');
    Wished_Marker_List     = get(handles.WishedMarkerList, 'String');
    % Add segment to WishedList
    Wished_Marker_List{length(Wished_Marker_List)+1} = Possible_Marker_List{Selected_Marker};
    set(handles.WishedMarkerList, 'String', Wished_Marker_List);
    % delete the added segment form PossibleList
    nb_mar = length(Possible_Marker_List);
    New_Marker_List = cell(nb_mar-1,1);
    j = 1;
    for i=1:1:nb_mar
        if i==Selected_Marker
            % do nothing
        else
            New_Marker_List{j,1} = Possible_Marker_List{i};
            j = j+1;
        end
    end
    set(handles.PossibleMarkerList, 'String', New_Marker_List);
    % Select a correct object
    if (Selected_Marker < (nb_mar-1))
        set(handles.PossibleMarkerList,'Value', Selected_Marker+1);
    else
        set(handles.PossibleMarkerList,'Value', nb_mar-1);
    end
    set(handles.WishedMarkerList,'Value', 1);


% --- Executes on button press in Rem_SelectedMarker.
function Rem_SelectedMarker_Callback(hObject, eventdata, handles)
% hObject    handle to Rem_SelectedMarker (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    % Get current parameters
    Selected_Marker        = get(handles.WishedMarkerList,'Value');
    Possible_Marker_List	= get(handles.PossibleMarkerList, 'String');
    Wished_Marker_List     = get(handles.WishedMarkerList, 'String');
     % Add segment to WishedList
    Possible_Marker_List{length(Possible_Marker_List)+1} = Wished_Marker_List{Selected_Marker};
    set(handles.PossibleMarkerList, 'String', Possible_Marker_List);
    % delete the added segment form PossibleList
    nb_mar           = length(Wished_Marker_List);
    New_Marker_List = cell(nb_mar-1,1);
    j = 1;
    for i=1:1:nb_mar
        if i==Selected_Marker
            % do nothing
        else
            New_Marker_List{j,1} = Wished_Marker_List{i};
            j = j+1;
        end
    end
    if (Selected_Marker < (nb_mar-1))
        set(handles.WishedMarkerList,'Value', Selected_Marker+1);
    else
        set(handles.WishedMarkerList,'Value', nb_mar-1);
    end
    set(handles.WishedMarkerList, 'String', New_Marker_List);
    set(handles.PossibleMarkerList,'Value', 1);


% --- Executes on button press in Apply.
function Apply_Callback(hObject, eventdata, handles)
% hObject    handle to Apply (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    % Recover the handles of the main figure
    MenuViconHandles    = handles.MenuViconHandles;
    % recover the wished segment to add
    Wished_Marker_List = get(handles.WishedMarkerList, 'String');
    Nb_MarToAdd = length(Wished_Marker_List);
    % recover previous segment
    Marker_List = get(MenuViconHandles.MarkerList,'String');
    Nb_Mar = length(Marker_List);
    for i=1:Nb_MarToAdd
        Marker_List{i+Nb_Mar,1} = Wished_Marker_List{i};
    end
    set(MenuViconHandles.MarkerList,'String', Marker_List);
    set(MenuViconHandles.MarkerList,'value', 1);
    close(handles.figure1);


% --- Executes on button press in Cancel.
function Cancel_Callback(hObject, eventdata, handles)
% hObject    handle to Cancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    close(handles.figure1)
