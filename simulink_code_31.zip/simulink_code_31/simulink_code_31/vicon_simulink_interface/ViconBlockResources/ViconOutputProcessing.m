%%%%%%%%%%%%%%%%%%%%%%%%% ViconOutputProcessing.m %%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% ViconOutputProcessing: Add or remove the needed output port of the Vicon Simulink Block.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Author: Augustin Manecy
%
% Copyright (C) 2011-2014 Augustin Manecy
%
% augustin.manecy@gmail.com
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This file is part of RT-MaG Toolbox.
%
%   RT-MaG Toolbox is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as published by
%   the Free Software Foundation, either version 3 of the License, or
%   (at your option) any later version.
%
%   RT-MaG Toolbox is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public License
%   along with RT-MaG Toolbox.  If not, see <http://www.gnu.org/licenses/>.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This version of GPL is at https://www.gnu.org/licenses/gpl-3.0.txt
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function ViconOutputProcessing(ViconStructure)
    %=== Give here the segment lenght depending of "Sfun_RecupVicon_SDK.m" ===%
    %
    %   A explaination of the length is given in function "mdlInitializeSizes" of "Sfun_RecupVicon_SDK.m"
    %
    SegmentLength = 13;
    MarkerLength = 3;
    NbOtherOutput = 5;
    %
    %=========================================================================%

    Vicon_Block = gcb;
    
    NbTotSegment         = 0;
    NbTotMarker          = 0;
    NbTotUnlabeledMarker = length(ViconStructure.UnlabeledMarker);
    
    if isfield(ViconStructure, 'Object')
        for i=1:1:length(ViconStructure.Object)
            NbTotSegment = NbTotSegment + ViconStructure.Object(i).NbSegment;
            NbTotMarker  = NbTotMarker + ViconStructure.Object(i).NbMarker;
        end
    else
        NbTotSegment = 0;
        NbTotMarker  = 0;
    end
    
    tab_Outport = find_system([Vicon_Block], 'LookUnderMasks', 'all',  'blocktype', 'Outport');
    % Look for the nb of Segment output
    SegmentBlockIndex = strfind(tab_Outport, 'Segment');
    NbCurrentSegment = 0;
    for i=1:1:length(SegmentBlockIndex)
        if (~isempty(SegmentBlockIndex{i}))
            NbCurrentSegment = NbCurrentSegment+1;
            SegmentBlockName{i} = tab_Outport{i};
        end
    end
    % Look for the nb of Segment output
    MarkerBlockIndex = strfind(tab_Outport, 'LabeledMarker');
    NbCurrentMarker = 0;
    for i=1:1:length(MarkerBlockIndex)
        if (~isempty(MarkerBlockIndex{i}))
            NbCurrentMarker = NbCurrentMarker+1;
            MarkerBlockName{i} = tab_Outport{i};
        end
    end
    % Look for the nb of Segment output
    UnlabeledMarkerBlockIndex = strfind(tab_Outport, 'UnlabeledMarker');
    NbCurrentUnlabeledMarker = 0;
    for i=1:1:length(UnlabeledMarkerBlockIndex)
        if (~isempty(UnlabeledMarkerBlockIndex{i}))
            NbCurrentUnlabeledMarker = NbCurrentUnlabeledMarker+1;
            UnlabeledMarkerBlockName{i} = tab_Outport{i};
        end
    end
    
    % adjust Mux param
    demux_param = '[1 1 1 3 3 ';
    for i=1:1:NbTotSegment
        demux_param = [demux_param num2str(SegmentLength) ' '];
    end
    for i=1:1:NbTotMarker
        demux_param = [demux_param num2str(MarkerLength) ' '];
    end
    for i=1:1:NbTotUnlabeledMarker
        demux_param = [demux_param num2str(MarkerLength) ' '];
    end
    demux_param = [demux_param ']'];
    
    % test if outputport have to be modify
    if ((NbCurrentSegment ~= NbTotSegment)||(NbCurrentMarker ~= NbTotMarker)||(NbCurrentUnlabeledMarker ~= NbTotUnlabeledMarker))
        % delete all mux line
        for i=(NbOtherOutput+1):1:(NbCurrentSegment+NbOtherOutput)
            delete_line(Vicon_Block, ['Vicon_Demux/' num2str(i)], ['Segment_' num2str(i-NbOtherOutput) '/1'])
        end
        for i=(NbCurrentSegment+NbOtherOutput+1):1:(NbCurrentSegment+NbOtherOutput+NbCurrentMarker)
            delete_line(Vicon_Block, ['Vicon_Demux/' num2str(i)], ['LabeledMarker_' num2str(i-NbOtherOutput-NbCurrentSegment) '/1'])
        end
        for i=(NbCurrentSegment+NbCurrentMarker+NbOtherOutput+1):1:(NbCurrentSegment+NbCurrentMarker+NbOtherOutput+NbCurrentUnlabeledMarker)
            delete_line(Vicon_Block, ['Vicon_Demux/' num2str(i)], ['UnlabeledMarker_' num2str(i-NbOtherOutput-NbCurrentSegment-NbCurrentMarker) '/1'])
        end
    end
   
    % Create the right number of segment outputs
    if (NbTotSegment == 0)
        % delete all block and line
        for i=1:1:length(SegmentBlockIndex)
            if (~isempty(SegmentBlockIndex{i}))
                delete_block(tab_Outport{i});
            end
        end
    elseif (NbCurrentSegment > NbTotSegment)
        % delete all extra Outport and their link with max
        for i=(NbTotSegment+NbOtherOutput+1):1:(NbCurrentSegment+NbOtherOutput)
            delete_block(tab_Outport{i})
        end
        % adjust the position of next block
        LastOutportName = tab_Outport{NbTotSegment+NbOtherOutput};
        CurrentPosition = get_param(LastOutportName, 'position');
            % determine the offset corresponding to the number of segment to add 
        for i=NbCurrentSegment+NbOtherOutput+1:1:NbCurrentSegment+NbOtherOutput+NbCurrentMarker+NbCurrentUnlabeledMarker
            CurrentPosition = CurrentPosition + [0 30 0 30];
            set_param(tab_Outport{i}, 'position', CurrentPosition);
        end
    elseif (NbCurrentSegment < NbTotSegment)
        % adjust position of next block which already exist
        LastOutportName = tab_Outport{NbCurrentSegment+NbOtherOutput};
        CurrentPosition = get_param(LastOutportName, 'position');
            % determine the offset corresponding to the number of segment to add 
        CurrentPosition = CurrentPosition + [0 30 0 30]*(NbTotSegment-NbCurrentSegment);
        for i=NbCurrentSegment+NbOtherOutput+1:1:NbCurrentSegment+NbOtherOutput+NbCurrentMarker+NbCurrentUnlabeledMarker
            CurrentPosition = CurrentPosition + [0 30 0 30];
            set_param(tab_Outport{i}, 'position', CurrentPosition);
        end
        % add Segment's missed Outport
        LastOutportName = tab_Outport{NbCurrentSegment+NbOtherOutput};
        CurrentPosition = get_param(LastOutportName, 'position');
        for i=1:1:(NbTotSegment-NbCurrentSegment)
            OutputNum = num2str(NbCurrentSegment + i);
            CurrentPosition = CurrentPosition + [0 30 0 30];
            add_block('Simulink/Sinks/Out1', [Vicon_Block '/Segment_' OutputNum], 'position', CurrentPosition);
            %add_line(Vicon_Block, ['Vicon_Demux/' num2str(i+1)], ['Segment_' OutputNum '/1']);
        end
    end
    %NbCurrentSegment = NbTotSegment;
    
    % Create the right number of marker outputs
    if (NbTotMarker == 0)
        % delete all block and line
        for i=1:1:length(MarkerBlockIndex)
            if (~isempty(MarkerBlockIndex{i}))
                delete_block(tab_Outport{i});
            end
        end
    elseif (NbCurrentMarker > NbTotMarker)
        % delete all extra Outport and their link with max
        for i=(NbCurrentSegment+NbTotMarker+NbOtherOutput+1):1:(NbCurrentSegment+NbCurrentMarker+NbOtherOutput)
            delete_block(tab_Outport{i})
        end
        % adjust the position of next block
        LastOutportName = tab_Outport{NbCurrentSegment+NbTotMarker+NbOtherOutput};
        CurrentPosition = get_param(LastOutportName, 'position');
            % determine the offset corresponding to the number of segment to add 
        for i=NbCurrentSegment+NbCurrentMarker+NbOtherOutput+1:1:NbCurrentSegment+NbOtherOutput+NbCurrentMarker+NbCurrentUnlabeledMarker
            CurrentPosition = CurrentPosition + [0 30 0 30];
            set_param(tab_Outport{i}, 'position', CurrentPosition);
        end
    elseif (NbCurrentMarker < NbTotMarker)
        % adjust position of next block which already exist
        LastOutportName = tab_Outport{NbCurrentSegment+NbCurrentMarker+NbOtherOutput};
        CurrentPosition = get_param(LastOutportName, 'position');
            % determine the offset corresponding to the number of segment to add 
        CurrentPosition = CurrentPosition + [0 30 0 30]*(NbTotMarker-NbCurrentMarker);
        for i=NbCurrentSegment+NbCurrentMarker+NbOtherOutput+1:1:NbCurrentSegment+NbOtherOutput+NbCurrentMarker+NbCurrentUnlabeledMarker
            CurrentPosition = CurrentPosition + [0 30 0 30];
            set_param(tab_Outport{i}, 'position', CurrentPosition);
        end
        % add Segment's missed Outport
        LastOutportName = tab_Outport{NbCurrentSegment+NbCurrentMarker+NbOtherOutput};
        CurrentPosition = get_param(LastOutportName, 'position');
        for i=1:1:(NbTotMarker-NbCurrentMarker)
            OutputNum = num2str(NbCurrentMarker + i);
            CurrentPosition = CurrentPosition + [0 30 0 30];
            add_block('Simulink/Sinks/Out1', [Vicon_Block '/LabeledMarker_' OutputNum], 'position', CurrentPosition);
            %add_line(Vicon_Block, ['Vicon_Demux/' num2str(i+1)], ['Segment_' OutputNum '/1']);
        end
    end
    %NbCurrentMarker = NbTotMarker;
    
     % Create the right number of marker outputs
    if (NbTotUnlabeledMarker == 0)
        % delete all block and line
        for i=1:1:length(UnlabeledMarkerBlockIndex)
            if (~isempty(UnlabeledMarkerBlockIndex{i}))
                delete_block(tab_Outport{i});
            end
        end
    elseif (NbCurrentUnlabeledMarker > NbTotMarker)
        % delete all extra Outport and their link with max
        for i=(NbCurrentSegment+NbCurrentMarker+NbTotUnlabeledMarker+NbOtherOutput+1):1:(NbCurrentSegment+NbCurrentMarker+NbCurrentUnlabeledMarker+NbOtherOutput)
            delete_block(tab_Outport{i})
        end
    elseif (NbCurrentUnlabeledMarker < NbTotUnlabeledMarker)
        % add Segment's missed Outport
        LastOutportName = tab_Outport{NbCurrentSegment+NbCurrentMarker+NbCurrentUnlabeledMarker+NbOtherOutput};
        CurrentPosition = get_param(LastOutportName, 'position');
        for i=1:1:(NbTotUnlabeledMarker-NbCurrentUnlabeledMarker)
            OutputNum = num2str(NbCurrentUnlabeledMarker + i);
            CurrentPosition = CurrentPosition + [0 30 0 30];
            add_block('Simulink/Sinks/Out1', [Vicon_Block '/UnlabeledMarker_' OutputNum], 'position', CurrentPosition);
            %add_line(Vicon_Block, ['Vicon_Demux/' num2str(i+1)], ['Segment_' OutputNum '/1']);
        end
    end
    
    % create the line between the outport and demux
    set_param([Vicon_Block '/Vicon_Demux'], 'outputs', demux_param)
    % delete all mux line
    if ((NbCurrentSegment ~= NbTotSegment)||(NbCurrentMarker ~= NbTotMarker)||(NbCurrentUnlabeledMarker ~= NbTotUnlabeledMarker))
        for i=(NbOtherOutput+1):1:(NbTotSegment+NbOtherOutput)
            add_line(Vicon_Block, ['Vicon_Demux/' num2str(i)], ['Segment_' num2str(i-NbOtherOutput) '/1'])
            set_param([Vicon_Block '/Segment_' num2str(i-NbOtherOutput)], 'Port', num2str(i));
        end
        for i=(NbTotSegment+NbOtherOutput+1):1:(NbTotSegment+NbOtherOutput+NbTotMarker)
            add_line(Vicon_Block, ['Vicon_Demux/' num2str(i)], ['LabeledMarker_' num2str(i-NbOtherOutput-NbTotSegment) '/1'])
            set_param([Vicon_Block '/LabeledMarker_' num2str(i-NbOtherOutput-NbTotSegment)], 'Port', num2str(i));
        end
        for i=(NbTotSegment+NbTotMarker+NbOtherOutput+1):1:(NbTotSegment+NbTotMarker+NbOtherOutput+NbTotUnlabeledMarker)
            add_line(Vicon_Block, ['Vicon_Demux/' num2str(i)], ['UnlabeledMarker_' num2str(i-NbOtherOutput-NbTotSegment-NbTotMarker) '/1'])
            set_param([Vicon_Block '/UnlabeledMarker_' num2str(i-NbOtherOutput-NbTotSegment-NbTotMarker)], 'Port', num2str(i));
        end
    end
    
end