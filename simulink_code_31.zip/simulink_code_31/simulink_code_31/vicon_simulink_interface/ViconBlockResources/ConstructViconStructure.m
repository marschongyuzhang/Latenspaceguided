%%%%%%%%%%%%%%%%%%%%%%%%% ConstructViconStructure.m %%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% ConstructViconStructure: Transform the mask parameters of the Vicon block 
%		into a matlab structure.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Author: Augustin Manecy
%
% Copyright (C) 2011-2014 Augustin Manecy
%
% augustin.manecy@gmail.com
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This file is part of RT-MaG Toolbox.
%
%   RT-MaG Toolbox is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as published by
%   the Free Software Foundation, either version 3 of the License, or
%   (at your option) any later version.
%
%   RT-MaG Toolbox is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public License
%   along with RT-MaG Toolbox.  If not, see <http://www.gnu.org/licenses/>.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This version of GPL is at https://www.gnu.org/licenses/gpl-3.0.txt
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function ViconStructure = ConstructViconStructure(IP, Port, SampleTime, SegmentList, MarkerList, UnlabeledMarker)

    ViconStructure.IP           = IP;
    ViconStructure.Port         = str2num(Port);
    ViconStructure.SampleTime   = str2num(SampleTime);

    NbObject = 0;

    for i=1:1:length(SegmentList)
        ObjectName = SegmentList{i}(1:find(SegmentList{i}=='.')-1);
        % test if it is a new object
        NewObject = 1;
        for j=1:1:NbObject
            if(strcmp(ViconStructure.Object(j).Name,ObjectName)==0)
                NewObject = NewObject&1;
            else
                NewObject = NewObject&0;
                CurrentObject = j;
            end
        end
        if NewObject==1
            % add the object to the list
            NbObject = NbObject+1;
            ViconStructure.Object(NbObject).Name = ObjectName; 
            ViconStructure.Object(NbObject).NbSegment = 1; 
            ViconStructure.Object(NbObject).NbMarker = 0;
            ViconStructure.Object(NbObject).Segment.Name = SegmentList{i}(find(SegmentList{i}=='.')+1:end);
        else
            % just add the segment to the existing object
            ViconStructure.Object(CurrentObject).NbSegment = ViconStructure.Object(CurrentObject).NbSegment+1;
            ViconStructure.Object(CurrentObject).Segment(ViconStructure.Object(CurrentObject).NbSegment).Name = SegmentList{i}(find(SegmentList{i}=='.')+1:end);
        end
    end
    
    for i=1:1:length(MarkerList)
        ObjectName = MarkerList{i}(1:find(MarkerList{i}=='.')-1);
        % test if it is a new object
        NewObject = 1;
        for j=1:1:NbObject
            if(strcmp(ViconStructure.Object(j).Name,ObjectName)==0)
                NewObject = NewObject&1;
            else
                NewObject = NewObject&0;
                CurrentObject = j;
            end
        end
        if NewObject==1
            % add the object to the list
            NbObject = NbObject+1;
            ViconStructure.Object(NbObject).Name = ObjectName; 
            ViconStructure.Object(NbObject).NbSegment = 0;
            ViconStructure.Object(NbObject).NbMarker = 1; 
            ViconStructure.Object(NbObject).Marker.Name = MarkerList{i}(find(MarkerList{i}=='.')+1:end);
        else
            % just add the segment to the existing object
            ViconStructure.Object(CurrentObject).NbMarker = ViconStructure.Object(CurrentObject).NbMarker+1;
            ViconStructure.Object(CurrentObject).Marker(ViconStructure.Object(CurrentObject).NbMarker).Name = MarkerList{i}(find(MarkerList{i}=='.')+1:end);
        end
    end
    
    [l,c] = size(UnlabeledMarker);
    if (l >= c)
        ViconStructure.UnlabeledMarker = str2num(UnlabeledMarker);
    else
        ViconStructure.UnlabeledMarker = (str2num(UnlabeledMarker))';
    end
    
end