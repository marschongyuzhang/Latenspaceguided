%%%%%%%%%%%%%%%%%%%%%%%%% ViconOutPortDisplay.m %%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% ViconOutPortDisplay: Displays information on the Simulink block thanks to
%		the parameters of the mask.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Author: Augustin Manecy
%
% Copyright (C) 2011-2014 Augustin Manecy
%
% augustin.manecy@gmail.com
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This file is part of RT-MaG Toolbox.
%
%   RT-MaG Toolbox is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as published by
%   the Free Software Foundation, either version 3 of the License, or
%   (at your option) any later version.
%
%   RT-MaG Toolbox is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public License
%   along with RT-MaG Toolbox.  If not, see <http://www.gnu.org/licenses/>.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This version of GPL is at https://www.gnu.org/licenses/gpl-3.0.txt
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ColorVector = {'blue';...
               'green';...
               'orange';...
               'red';...
               'gray';...
               'magenta';...
               'cyan';...
               'yellow'};

BlockPosition = get_param(gcb, 'position');        

%% recover parameters
CurrentBlock = gcb;

% construct edit_IP
IP = get_param(CurrentBlock, 'IP_Vicon');

% construct edit_Port
Port = get_param(CurrentBlock, 'Port_Vicon');

% Construct SampleTime
SampleTime = get_param(CurrentBlock, 'Ts_Vicon');

% Construct UnlabeledMarker
UnlabeledMarker = get_param(CurrentBlock, 'UnlabeledMarker');

% Contruct SegmentList and MarkerList
ObjectTab = str2num(get_param(CurrentBlock, 'ObjectTab'));
ObjectName = get_param(CurrentBlock, 'ObjectName');
SegmentName = get_param(CurrentBlock, 'SegmentName');
MarkerName = get_param(CurrentBlock, 'MarkerName');

[NbObject, ~]   = size(ObjectTab);
NbSegment       = 1;
NbMarker        = 1;
ObjectDelimiterIndex    = find(ObjectName==',');
SegmentdelimiterIndex   = find(SegmentName==',');
NbTotSegment = length(SegmentdelimiterIndex)+1;
MarkerDelimiterIndex    = find(MarkerName==',');
NbTotMarker = length(MarkerDelimiterIndex)+1;
SegmentList = {};
MarkerList = {};
% for each object
for i=1:1:NbObject
    switch i
        case 1
            if isempty(ObjectDelimiterIndex)
                CurrentObjectName = ObjectName(2:end-1);
            else
                CurrentObjectName = ObjectName(2:ObjectDelimiterIndex(1)-1);
            end
        case NbObject
            CurrentObjectName = ObjectName(ObjectDelimiterIndex(end)+1:end-1);
        otherwise
            CurrentObjectName = ObjectName(ObjectDelimiterIndex(i-1)+1:ObjectDelimiterIndex(i)-1);
    end
    % for each segment of this object
    for j=1:1:ObjectTab(i, 1)
        switch NbSegment
            case 1
                if isempty(SegmentdelimiterIndex)
                    CurrentSegmentName = SegmentName(2:end-1);
                else
                    CurrentSegmentName = SegmentName(2:SegmentdelimiterIndex(1)-1);
                end
            case NbTotSegment
                CurrentSegmentName = SegmentName(SegmentdelimiterIndex(end)+1:end-1);
            otherwise
                CurrentSegmentName = SegmentName(SegmentdelimiterIndex(NbSegment-1)+1:SegmentdelimiterIndex(NbSegment)-1);
        end
        SegmentList{NbSegment} = [CurrentObjectName '.' CurrentSegmentName];
        NbSegment = NbSegment+1;
    end
    % for each marker of this object
    for j=1:1:ObjectTab(i, 2)
        switch NbMarker
            case 1
                if isempty(MarkerDelimiterIndex)
                    CurrentMarkerName = MarkerName(2:end-1);
                else
                    CurrentMarkerName = MarkerName(2:MarkerDelimiterIndex(1)-1);
                end
            case NbTotMarker
                CurrentMarkerName = MarkerName(MarkerDelimiterIndex(end)+1:end-1);
            otherwise
                CurrentMarkerName = MarkerName(MarkerDelimiterIndex(NbMarker-1)+1:MarkerDelimiterIndex(NbMarker)-1);
        end
        MarkerList{NbMarker} = [CurrentObjectName '.' CurrentMarkerName];
        NbMarker = NbMarker+1;
    end
end     

ViconStructure = ConstructViconStructure(IP, Port, SampleTime, SegmentList, MarkerList, UnlabeledMarker);

%% display the right name for the right outport

if isfield(ViconStructure, 'Object')
    NbObject = length(ViconStructure.Object);
else
    NbObject = 0;
end

color('black')
port_label('output', 1, 'NewStream?');
port_label('output', 2, 'FrameNumber');
port_label('output', 3, 'Latency [s]');
color('blue')
port_label('output', 4, 'EyeTracker: Position [mm]');
port_label('output', 5, 'EyeTracker: Gaze Vector [mm]');

NumOutport = 6;

for i=1:1:NbObject
    color(ColorVector{mod(i, length(ColorVector))+1})
    for j=1:1:ViconStructure.Object(i).NbSegment
        port_label('output', NumOutport, ['SEG: ' ViconStructure.Object(i).Name '.' ViconStructure.Object(i).Segment(j).Name])
        NumOutport = NumOutport + 1;
    end
end

for i=1:1:NbObject
    color(ColorVector{mod(i, length(ColorVector))+1})
    for j=1:1:ViconStructure.Object(i).NbMarker
        port_label('output', NumOutport, ['MRK: ' ViconStructure.Object(i).Name '.' ViconStructure.Object(i).Marker(j).Name])
        NumOutport = NumOutport + 1;
    end
end

color('black')
for j=1:1:length(ViconStructure.UnlabeledMarker)
    port_label('output', NumOutport, ['Unlabeled Marker n�' num2str(ViconStructure.UnlabeledMarker(j))])
    NumOutport = NumOutport + 1;
end

% display the image
ImageWidth = 116;
ImageHeight = 247;
ImageRatio = ImageHeight/ImageWidth;

BlockWidth = abs(BlockPosition(3)-BlockPosition(1));
BlockHeight = abs(BlockPosition(2)-BlockPosition(4));

NormalizedHeight = 3/NumOutport;
Height = NormalizedHeight*BlockHeight;
Width = Height/ImageRatio;
NormalizedWidth = Width/BlockWidth;

% normalized position of image
% [left_offset_of_left_bottom_corner height_of_left_bottom_corner width height]
%image(imread('Vicon.jpg'),[0.5-NormalizedWidth/2 1-NormalizedHeight NormalizedWidth NormalizedHeight]); 
