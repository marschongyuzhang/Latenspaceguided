function varargout = ViconBlockMenu(varargin)
% VICONBLOCKMENU MATLAB code for ViconBlockMenu.fig
%      VICONBLOCKMENU, by itself, creates a new VICONBLOCKMENU or raises the existing
%      singleton*.
%
%      H = VICONBLOCKMENU returns the handle to a new VICONBLOCKMENU or the handle to
%      the existing singleton*.
%
%      VICONBLOCKMENU('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in VICONBLOCKMENU.M with the given input arguments.
%
%      VICONBLOCKMENU('Property','Value',...) creates a new VICONBLOCKMENU or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ViconBlockMenu_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ViconBlockMenu_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ViconBlockMenu

% Last Modified by GUIDE v2.5 13-Jun-2014 15:41:48

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ViconBlockMenu_OpeningFcn, ...
                   'gui_OutputFcn',  @ViconBlockMenu_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT
end

% --- Executes just before ViconBlockMenu is made visible.
function ViconBlockMenu_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ViconBlockMenu (see VARARGIN)

    % Choose default command line output for ViconBlockMenu
    handles.output = hObject;

    % Update handles structure
    guidata(hObject, handles);

    %LoadState(handles);
    LoadDlgParametersFromMaskedBlock(handles)


    % UIWAIT makes ViconBlockMenu wait for user response (see UIRESUME)
    % uiwait(handles.figure1);
end

% --- Outputs from this function are returned to the command line.
function varargout = ViconBlockMenu_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    % Get default command line output from handles structure
    varargout{1} = handles.output;
end


function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    % Hints: get(hObject,'String') returns contents of edit1 as text
    %        str2double(get(hObject,'String')) returns contents of edit1 as a double
end

% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

    % Hint: edit controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end


function edit_CustomSegment_Callback(hObject, eventdata, handles)
% hObject    handle to edit_CustomSegment (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    % Hints: get(hObject,'String') returns contents of edit_CustomSegment as text
    %        str2double(get(hObject,'String')) returns contents of edit_CustomSegment as a double
end

% --- Executes during object creation, after setting all properties.
function edit_CustomSegment_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_CustomSegment (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

    % Hint: edit controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end


% --- Executes on button press in Add_CustomSegment.
function Add_CustomSegment_Callback(hObject, eventdata, handles)
% hObject    handle to Add_CustomSegment (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    Custom_Segment  = get(handles.edit_CustomSegment, 'String');
    Segment_List    = get(handles.SegmentList, 'String');
    nb_seg = length(Segment_List)+1;
    Segment_List{nb_seg} = Custom_Segment;
    set(handles.SegmentList,'String', Segment_List)
    set(handles.SegmentList,'Value', nb_seg);
end

% --- Executes on button press in Explorer_Segment.
function Explorer_Segment_Callback(hObject, eventdata, handles)
% hObject    handle to Explorer_Segment (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    IP = get(handles.edit_IP, 'String');
    Port = get(handles.edit_Port, 'String');
    HostName = [IP ':' Port];

    [MyClient, ConnectionError] = Vicon_Connect(HostName);
    if (ConnectionError == 0)
        % Get the first frame
        [Segment_List, ReceptionError] = GetViconSegmentList(MyClient);
        if (ReceptionError == 0)
            Vicon_Disconnect(MyClient);
            Vicon_Choose_Segments(Segment_List, handles);
        else
            Vicon_Disconnect(MyClient);
            errordlg('Unable to Receive Frame! => Check that Vicon is turned on...','Reception Error')
        end
    else
        errordlg('Unable to connect to Host!','Connection Error')
    end
end



% --- Executes on button press in Rem_CustomSegment.
function Rem_CustomSegment_Callback(hObject, eventdata, handles)
% hObject    handle to Rem_CustomSegment (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    Selected_Segment = get(handles.SegmentList,'Value');
    Segment_List     = get(handles.SegmentList, 'String');
    nb_seg           = length(Segment_List);
    New_Segment_List = cell(nb_seg-1,1);
    j = 1;
    for i=1:1:nb_seg
        if i==Selected_Segment
            % do nothing
        else
            New_Segment_List{j,1} = Segment_List{i};
            j = j+1;
        end
    end
    if (Selected_Segment < (nb_seg-1))
        set(handles.SegmentList,'Value', Selected_Segment+1);
    else
        set(handles.SegmentList,'Value', nb_seg-1);
    end
    set(handles.SegmentList, 'String', New_Segment_List);
end


function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    % Hints: get(hObject,'String') returns contents of edit5 as text
    %        str2double(get(hObject,'String')) returns contents of edit5 as a double
end

% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

    % Hint: edit controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end


function edit_CustomMarker_Callback(hObject, eventdata, handles)
% hObject    handle to edit_CustomMarker (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    % Hints: get(hObject,'String') returns contents of edit_CustomMarker as text
    %        str2double(get(hObject,'String')) returns contents of edit_CustomMarker as a double
end

% --- Executes during object creation, after setting all properties.
function edit_CustomMarker_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_CustomMarker (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

    % Hint: edit controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end


% --- Executes on button press in Add_CustomMarker.
function Add_CustomMarker_Callback(hObject, eventdata, handles)
% hObject    handle to Add_CustomMarker (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    Custom_Marker  = get(handles.edit_CustomMarker, 'String');
    Marker_List    = get(handles.MarkerList, 'String');
    nb_mar = length(Marker_List)+1;
    Marker_List{nb_mar} = Custom_Marker;
    set(handles.MarkerList,'String', Marker_List)
    set(handles.MarkerList,'Value', nb_mar);
end

% --- Executes on button press in Explorer_Marker.
function Explorer_Marker_Callback(hObject, eventdata, handles)
% hObject    handle to Explorer_Marker (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    IP = get(handles.edit_IP, 'String');
    Port = get(handles.edit_Port, 'String');
    HostName = [IP ':' Port];

    [MyClient, ConnectionError] = Vicon_Connect(HostName);
    if (ConnectionError == 0)
        % Get the first frame
        [Marker_List, ReceptionError] = GetViconMarkerList(MyClient);
        if (ReceptionError == 0)
            Vicon_Disconnect(MyClient);
            Vicon_Choose_Markers(Marker_List, handles);
        else
            Vicon_Disconnect(MyClient);
            errordlg('Unable to Receive Frame! => Check that Vicon is turned on...','Reception Error')
        end
    else
        errordlg('Unable to connect to Host!','Connection Error')
    end
end

% --- Executes on button press in Rem_CustomMarker.
function Rem_CustomMarker_Callback(hObject, eventdata, handles)
% hObject    handle to Rem_CustomMarker (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    Selected_Marker = get(handles.MarkerList,'Value');
    Marker_List     = get(handles.MarkerList, 'String');
    nb_mar           = length(Marker_List);
    New_Marker_List = cell(nb_mar-1,1);
    j = 1;
    for i=1:1:nb_mar
        if i==Selected_Marker
            % do nothing
        else
            New_Marker_List{j,1} = Marker_List{i};
            j = j+1;
        end
    end
    if (Selected_Marker < (nb_mar-1))
        set(handles.MarkerList,'Value', Selected_Marker+1);
    else
        set(handles.MarkerList,'Value', nb_mar-1);
    end
    set(handles.MarkerList, 'String', New_Marker_List);
end

function edit_IP_Callback(hObject, eventdata, handles)
% hObject    handle to edit_IP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    % Hints: get(hObject,'String') returns contents of edit_IP as text
    %        str2double(get(hObject,'String')) returns contents of edit_IP as a double

end

% --- Executes during object creation, after setting all properties.
function edit_IP_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_IP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

    % Hint: edit controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end



function edit_Port_Callback(hObject, eventdata, handles)
% hObject    handle to edit_Port (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    % Hints: get(hObject,'String') returns contents of edit_Port as text
    %        str2double(get(hObject,'String')) returns contents of edit_Port as a double
end

% --- Executes during object creation, after setting all properties.
function edit_Port_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_Port (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

    % Hint: edit controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end



function UnlabeledMarker_Callback(hObject, eventdata, handles)
% hObject    handle to UnlabeledMarker (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    % Hints: get(hObject,'String') returns contents of UnlabeledMarker as text
    %        str2double(get(hObject,'String')) returns contents of UnlabeledMarker as a double
end

% --- Executes during object creation, after setting all properties.
function UnlabeledMarker_CreateFcn(hObject, eventdata, handles)
% hObject    handle to UnlabeledMarker (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

    % Hint: edit controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end



function SampleTime_Callback(hObject, eventdata, handles)
% hObject    handle to SampleTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    % Hints: get(hObject,'String') returns contents of SampleTime as text
    %        str2double(get(hObject,'String')) returns contents of SampleTime as a double
end

% --- Executes during object creation, after setting all properties.
function SampleTime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SampleTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

    % Hint: edit controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end


% --- Executes on selection change in MarkerList.
function MarkerList_Callback(hObject, eventdata, handles)
% hObject    handle to MarkerList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    % Hints: contents = cellstr(get(hObject,'String')) returns MarkerList contents as cell array
    %        contents{get(hObject,'Value')} returns selected item from MarkerList
end

% --- Executes during object creation, after setting all properties.
function MarkerList_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MarkerList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

    % Hint: listbox controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end

% --- Executes on selection change in SegmentList.
function SegmentList_Callback(hObject, eventdata, handles)
% hObject    handle to SegmentList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    % Hints: contents = cellstr(get(hObject,'String')) returns SegmentList contents as cell array
    %        contents{get(hObject,'Value')} returns selected item from SegmentList
end

% --- Executes during object creation, after setting all properties.
function SegmentList_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SegmentList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

    % Hint: listbox controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end


% --- Executes on button press in Apply.
function Apply_Callback(hObject, eventdata, handles)
% hObject    handle to Apply (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    % recover SegmentList, MarkerList and UnlabeledMarkers
    SegmentList     = get(handles.SegmentList, 'String');
    MarkerList      = get(handles.MarkerList, 'String');
    UnlabeledMarker	= get(handles.UnlabeledMarker, 'String');
    IP              = get(handles.edit_IP, 'String');
    Port            = get(handles.edit_Port, 'String');
    SampleTime      = get(handles.SampleTime, 'String');
    % genere the vicon structure
    ViconStructure = ConstructViconStructure(IP, Port, SampleTime, SegmentList, MarkerList, UnlabeledMarker);
    assignin('base', 'ViconStructure', ViconStructure);
    [IP, Port, SampleTime, ObjectTab, UnlabeledMarker, ObjectName, SegmentName, MarkerName] = ConstructSfunParameters(ViconStructure);
    % genere the parameters for masked vicon block   
    ViconBlock = gcb;
    set_param(ViconBlock, 'IP_Vicon', IP);
    set_param(ViconBlock, 'Port_Vicon', Port);
    set_param(ViconBlock, 'Ts_Vicon', SampleTime);
    set_param(ViconBlock, 'ObjectTab', ObjectTab);
    set_param(ViconBlock, 'UnlabeledMarker', UnlabeledMarker);
    set_param(ViconBlock, 'ObjectName', ObjectName);
    set_param(ViconBlock, 'SegmentName', SegmentName);
    set_param(ViconBlock, 'MarkerName', MarkerName);
    % Adapt the output ports
    ViconOutputProcessing(ViconStructure);
    % save the data
    %SaveState(handles, ViconStructure);
end


% --- Executes on button press in Cancel.
function Cancel_Callback(hObject, eventdata, handles)
% hObject    handle to Cancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    close(handles.figure1);
end

% --- Executes on button press in OK.
function OK_Callback(hObject, eventdata, handles)
% hObject    handle to OK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    % recover SegmentList, MarkerList and UnlabeledMarkers
    SegmentList     = get(handles.SegmentList, 'String');
    MarkerList      = get(handles.MarkerList, 'String');
    UnlabeledMarker	= get(handles.UnlabeledMarker, 'String');
    IP              = get(handles.edit_IP, 'String');
    Port            = get(handles.edit_Port, 'String');
    SampleTime      = get(handles.SampleTime, 'String');
    % genere the vicon structure
    ViconStructure = ConstructViconStructure(IP, Port, SampleTime, SegmentList, MarkerList, UnlabeledMarker);
    assignin('base', 'ViconStructure', ViconStructure);
    [IP, Port, SampleTime, ObjectTab, UnlabeledMarker, ObjectName, SegmentName, MarkerName] = ConstructSfunParameters(ViconStructure);
    % genere the parameters for masked vicon block   
    ViconBlock = gcb;
    set_param(ViconBlock, 'IP_Vicon', IP);
    set_param(ViconBlock, 'Port_Vicon', Port);
    set_param(ViconBlock, 'Ts_Vicon', SampleTime);
    set_param(ViconBlock, 'ObjectTab', ObjectTab);
    set_param(ViconBlock, 'UnlabeledMarker', UnlabeledMarker);
    set_param(ViconBlock, 'ObjectName', ObjectName);
    set_param(ViconBlock, 'SegmentName', SegmentName);
    set_param(ViconBlock, 'MarkerName', MarkerName);
    % Adapt the output ports
    ViconOutputProcessing(ViconStructure);
    % save the data
    % SaveState(handles, ViconStructure);
    % close the mask
    close(handles.figure1);
end
    
% function SaveState(handles, ViconStructure)
%     % recover SegmentList, MarkerList and UnlabeledMarkers
%     State.SegmentList     = get(handles.SegmentList, 'String');
%     State.MarkerList      = get(handles.MarkerList, 'String');
%     State.UnlabeledMarker = get(handles.UnlabeledMarker, 'String');
%     State.edit_IP         = get(handles.edit_IP, 'String');
%     State.edit_Port       = get(handles.edit_Port, 'String');
%     State.SampleTime      = get(handles.SampleTime, 'String');
%     
%     save('ViconBlockMenu_State.mat', 'State', 'ViconStructure');
% end

% 
% function LoadState(handles)
%     if exist('ViconBlockMenu_State.mat')
%         
%         load ViconBlockMenu_State.mat
%         
%         % recover SegmentList, MarkerList and UnlabeledMarkers
%         set(handles.SegmentList, 'String', State.SegmentList);
%         set(handles.MarkerList, 'String', State.MarkerList);
%         set(handles.UnlabeledMarker, 'String', State.UnlabeledMarker);
%         set(handles.edit_IP, 'String', State.edit_IP);
%         set(handles.edit_Port, 'String', State.edit_Port);
%         set(handles.SampleTime, 'String', State.SampleTime);
%     end
% end

function LoadDlgParametersFromMaskedBlock(handles)

    handles.CurrentBlock = gcb;
    
    % construct edit_IP
    IP = get_param(handles.CurrentBlock, 'IP_Vicon');
    set(handles.edit_IP, 'String', IP(2:end-1));
    
    % construct edit_Port
    Port = get_param(handles.CurrentBlock, 'Port_Vicon');
    set(handles.edit_Port, 'String', Port);
    
    % Construct SampleTime
    SampleTime = get_param(handles.CurrentBlock, 'Ts_Vicon');
    set(handles.SampleTime, 'String', SampleTime);
    
    % Construct UnlabeledMarker
    UnlabeledMarker = get_param(handles.CurrentBlock, 'UnlabeledMarker');
    set(handles.UnlabeledMarker, 'String', UnlabeledMarker);
    
    % Contruct SegmentList and MarkerList
    ObjectTab = str2num(get_param(handles.CurrentBlock, 'ObjectTab'));
    ObjectName = get_param(handles.CurrentBlock, 'ObjectName');
    SegmentName = get_param(handles.CurrentBlock, 'SegmentName');
    MarkerName = get_param(handles.CurrentBlock, 'MarkerName');
    
    [NbObject, ~]   = size(ObjectTab);
    NbSegment       = 1;
    NbMarker        = 1;
    ObjectDelimiterIndex    = find(ObjectName==',');
    SegmentdelimiterIndex   = find(SegmentName==',');
    NbTotSegment = length(SegmentdelimiterIndex)+1;
    MarkerDelimiterIndex    = find(MarkerName==',');
    NbTotMarker = length(MarkerDelimiterIndex)+1;
    SegmentList = {};
    MarkerList = {};
    % for each object
    for i=1:1:NbObject
        switch i
            case 1
                if isempty(ObjectDelimiterIndex)
                    CurrentObjectName = ObjectName(2:end-1);
                else
                    CurrentObjectName = ObjectName(2:ObjectDelimiterIndex(1)-1);
                end
            case NbObject
                CurrentObjectName = ObjectName(ObjectDelimiterIndex(end)+1:end-1);
            otherwise
                CurrentObjectName = ObjectName(ObjectDelimiterIndex(i-1)+1:ObjectDelimiterIndex(i)-1);
        end
        % for each segment of this object
        for j=1:1:ObjectTab(i, 1)
            switch NbSegment
                case 1
                    if isempty(SegmentdelimiterIndex)
                        CurrentSegmentName = SegmentName(2:end-1);
                    else
                        CurrentSegmentName = SegmentName(2:SegmentdelimiterIndex(1)-1);
                    end
                case NbTotSegment
                    CurrentSegmentName = SegmentName(SegmentdelimiterIndex(end)+1:end-1);
                otherwise
                    CurrentSegmentName = SegmentName(SegmentdelimiterIndex(NbSegment-1)+1:SegmentdelimiterIndex(NbSegment)-1);
            end
            SegmentList{NbSegment} = [CurrentObjectName '.' CurrentSegmentName];
            NbSegment = NbSegment+1;
        end
        % for each marker of this object
        for j=1:1:ObjectTab(i, 2)
            switch NbMarker
                case 1
                    if isempty(MarkerDelimiterIndex)
                        CurrentMarkerName = MarkerName(2:end-1);
                    else
                        CurrentMarkerName = MarkerName(2:MarkerDelimiterIndex(1)-1);
                    end
                case NbTotMarker
                    CurrentMarkerName = MarkerName(MarkerDelimiterIndex(end)+1:end-1);
                otherwise
                    CurrentMarkerName = MarkerName(MarkerDelimiterIndex(NbMarker-1)+1:MarkerDelimiterIndex(NbMarker)-1);
            end
            MarkerList{NbMarker} = [CurrentObjectName '.' CurrentMarkerName];
            NbMarker = NbMarker+1;
        end
    end     
    set(handles.SegmentList, 'String', SegmentList);
    set(handles.MarkerList, 'String', MarkerList);
    
end
