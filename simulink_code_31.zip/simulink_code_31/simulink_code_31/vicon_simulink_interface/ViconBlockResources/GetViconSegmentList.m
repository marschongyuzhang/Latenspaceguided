%%%%%%%%%%%%%%%%%%%%%%%%% GetViconSegmentList.m %%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% GetViconSegmentList: Recover the list of segment available thanks to the Vicon MATLAB SDK.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Author: Augustin Manecy
%
% Copyright (C) 2011-2014 Augustin Manecy
%
% augustin.manecy@gmail.com
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This file is part of RT-MaG Toolbox.
%
%   RT-MaG Toolbox is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as published by
%   the Free Software Foundation, either version 3 of the License, or
%   (at your option) any later version.
%
%   RT-MaG Toolbox is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public License
%   along with RT-MaG Toolbox.  If not, see <http://www.gnu.org/licenses/>.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This version of GPL is at https://www.gnu.org/licenses/gpl-3.0.txt
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [Segment_List, ReceptionError] = GetViconSegmentList(MyClient)

    % Get a frame

    fprintf( 'Waiting for first frame.' );  
    error = MyClient.GetFrame().Result.Value;
    Nb_Try = 1;
    while ((error~=Result.Success) && (Nb_Try < 5))
      error = MyClient.GetFrame().Result.Value;

      if (toc > 5)
        break;
      end

      if(abs(mod(toc, 0.5)) <= 0.05)
        fprintf( '.' );
      end

    end
    fprintf( '\n' );

    if (error~=Result.Success)
        ReceptionError = 1; 
        Segment_List = {};
    else
        ReceptionError = 0;
      % Get the frame number
      Output_GetFrameNumber = MyClient.GetFrameNumber();
      fprintf( 'Frame Number: %d\n', Output_GetFrameNumber.FrameNumber );

      % Get the timecode
      Output_GetTimecode = MyClient.GetTimecode();
      fprintf( 'Timecode: %dh %dm %ds %df %dsf %d %s %d %d\n\n', ...
                         Output_GetTimecode.Hours,               ...
                         Output_GetTimecode.Minutes,             ...
                         Output_GetTimecode.Seconds,             ...
                         Output_GetTimecode.Frames,              ...
                         Output_GetTimecode.SubFrame,            ...
                         Output_GetTimecode.FieldFlag,           ...
                         Output_GetTimecode.Standard.ToString(), ...
                         Output_GetTimecode.SubFramesPerFrame,   ...
                         Output_GetTimecode.UserBits );

      % Get the latency
      fprintf( 'Latency: %gs\n', MyClient.GetLatencyTotal().Total );

      for LatencySampleIndex = 1:MyClient.GetLatencySampleCount().Count
        SampleName  = MyClient.GetLatencySampleName( LatencySampleIndex ).Name;
        SampleValue = MyClient.GetLatencySampleValue( SampleName ).Value;

        fprintf( '  %s %gs\n', SampleName, SampleValue );
      end% for  
      fprintf( '\n' );

      Nb_Segment = 1;
      % Count the number of subjects
      SubjectCount = MyClient.GetSubjectCount().SubjectCount;
      fprintf( 'Subjects (%d):\n', SubjectCount );
      for SubjectIndex = 1:SubjectCount
        fprintf( '  Subject #%d\n', SubjectIndex );

        % Get the subject name
        SubjectName = MyClient.GetSubjectName( SubjectIndex ).SubjectName;
        fprintf( '    Name: %s\n', SubjectName );

        % Get the root segment
        RootSegment = MyClient.GetSubjectRootSegmentName( SubjectName ).SegmentName;
        fprintf( '    Root Segment: %s\n', RootSegment );

        % Count the number of segments
        SegmentCount = MyClient.GetSegmentCount( SubjectName ).SegmentCount;
        fprintf( '    Segments (%d):\n', SegmentCount );
        for SegmentIndex = 1:SegmentCount
          fprintf( '      Segment #%d\n', SegmentIndex );

          % Get the segment name
          SegmentName = MyClient.GetSegmentName( SubjectName, SegmentIndex ).SegmentName;
          fprintf( '        Name: %s\n', SegmentName );

          % Get the segment parent
          SegmentParentName = MyClient.GetSegmentParentName( SubjectName, SegmentName ).SegmentName;
          fprintf( '        Parent: %s\n',  SegmentParentName );

          % Get the segment's children
          ChildCount = MyClient.GetSegmentChildCount( SubjectName, SegmentName ).SegmentCount;
          fprintf( '     Children (%d)\n', ChildCount );
          for ChildIndex = 1:ChildCount
            ChildName = MyClient.GetSegmentChildName( SubjectName, SegmentName, ChildIndex ).SegmentName;
            fprintf( '       %s\n', ChildName );
          end% for  

          % Get the global segment rotation in helical co-ordinates
          Output_GetSegmentGlobalRotationHelical = MyClient.GetSegmentGlobalRotationHelical( SubjectName, SegmentName );
          fprintf( '        Global Rotation Helical: (%g,%g,%g) %d\n',             ...
                             Output_GetSegmentGlobalRotationHelical.Rotation( 1 ), ...
                             Output_GetSegmentGlobalRotationHelical.Rotation( 2 ), ...
                             Output_GetSegmentGlobalRotationHelical.Rotation( 3 ), ...
                             Output_GetSegmentGlobalRotationHelical.Occluded );

          % Get the global segment rotation as a matrix
          Output_GetSegmentGlobalRotationMatrix = MyClient.GetSegmentGlobalRotationMatrix( SubjectName, SegmentName );
          fprintf( '        Global Rotation Matrix: (%g,%g,%g,%g,%g,%g,%g,%g,%g) %d\n', ...
                             Output_GetSegmentGlobalRotationMatrix.Rotation( 1 ),       ...
                             Output_GetSegmentGlobalRotationMatrix.Rotation( 2 ),       ...
                             Output_GetSegmentGlobalRotationMatrix.Rotation( 3 ),       ...
                             Output_GetSegmentGlobalRotationMatrix.Rotation( 4 ),       ...
                             Output_GetSegmentGlobalRotationMatrix.Rotation( 5 ),       ...
                             Output_GetSegmentGlobalRotationMatrix.Rotation( 6 ),       ...
                             Output_GetSegmentGlobalRotationMatrix.Rotation( 7 ),       ...
                             Output_GetSegmentGlobalRotationMatrix.Rotation( 8 ),       ...
                             Output_GetSegmentGlobalRotationMatrix.Rotation( 9 ),       ...
                             Output_GetSegmentGlobalRotationMatrix.Occluded );

          % Get the global segment rotation in quaternion co-ordinates
          Output_GetSegmentGlobalRotationQuaternion = MyClient.GetSegmentGlobalRotationQuaternion( SubjectName, SegmentName );
          fprintf( '        Global Rotation Quaternion: (%g,%g,%g,%g) %d\n', ...
                             Output_GetSegmentGlobalRotationQuaternion.Rotation( 1 ),       ...
                             Output_GetSegmentGlobalRotationQuaternion.Rotation( 2 ),       ...
                             Output_GetSegmentGlobalRotationQuaternion.Rotation( 3 ),       ...
                             Output_GetSegmentGlobalRotationQuaternion.Rotation( 4 ),       ...
                             Output_GetSegmentGlobalRotationQuaternion.Occluded );

          % Get the global segment rotation in EulerXYZ co-ordinates
          Output_GetSegmentGlobalRotationEulerXYZ = MyClient.GetSegmentGlobalRotationEulerXYZ( SubjectName, SegmentName );
          fprintf( '        Global Rotation EulerXYZ: (%g,%g,%g) %d\n', ...
                             Output_GetSegmentGlobalRotationEulerXYZ.Rotation( 1 ),       ...
                             Output_GetSegmentGlobalRotationEulerXYZ.Rotation( 2 ),       ...
                             Output_GetSegmentGlobalRotationEulerXYZ.Rotation( 3 ),       ...
                             Output_GetSegmentGlobalRotationEulerXYZ.Occluded );

          % Get the local segment translation
          Output_GetSegmentLocalTranslation = MyClient.GetSegmentLocalTranslation( SubjectName, SegmentName );
          fprintf( '        Local Translation: (%g,%g,%g) %d\n',                 ...
                             Output_GetSegmentLocalTranslation.Translation( 1 ), ...
                             Output_GetSegmentLocalTranslation.Translation( 2 ), ...
                             Output_GetSegmentLocalTranslation.Translation( 3 ), ...
                             Output_GetSegmentLocalTranslation.Occluded );

          % Get the local segment rotation in helical co-ordinates
          Output_GetSegmentLocalRotationHelical = MyClient.GetSegmentLocalRotationHelical( SubjectName, SegmentName );
          fprintf( '        Local Rotation Helical: (%g,%g,%g) %d\n',             ...
                             Output_GetSegmentLocalRotationHelical.Rotation( 1 ), ...
                             Output_GetSegmentLocalRotationHelical.Rotation( 2 ), ...
                             Output_GetSegmentLocalRotationHelical.Rotation( 3 ), ...
                             Output_GetSegmentLocalRotationHelical.Occluded );

          % Get the local segment rotation as a matrix
          Output_GetSegmentLocalRotationMatrix = MyClient.GetSegmentLocalRotationMatrix( SubjectName, SegmentName );
          fprintf( '        Local Rotation Matrix: (%g,%g,%g,%g,%g,%g,%g,%g,%g) %d\n', ...
                             Output_GetSegmentLocalRotationMatrix.Rotation( 1 ),       ...
                             Output_GetSegmentLocalRotationMatrix.Rotation( 2 ),       ...
                             Output_GetSegmentLocalRotationMatrix.Rotation( 3 ),       ...
                             Output_GetSegmentLocalRotationMatrix.Rotation( 4 ),       ...
                             Output_GetSegmentLocalRotationMatrix.Rotation( 5 ),       ...
                             Output_GetSegmentLocalRotationMatrix.Rotation( 6 ),       ...
                             Output_GetSegmentLocalRotationMatrix.Rotation( 7 ),       ...
                             Output_GetSegmentLocalRotationMatrix.Rotation( 8 ),       ...
                             Output_GetSegmentLocalRotationMatrix.Rotation( 9 ),       ...
                             Output_GetSegmentLocalRotationMatrix.Occluded );

          % Get the local segment rotation in quaternion co-ordinates
          Output_GetSegmentLocalRotationQuaternion = MyClient.GetSegmentLocalRotationQuaternion( SubjectName, SegmentName );
          fprintf( '        Local Rotation Quaternion: (%g,%g,%g,%g) %d\n', ...
                             Output_GetSegmentLocalRotationQuaternion.Rotation( 1 ),       ...
                             Output_GetSegmentLocalRotationQuaternion.Rotation( 2 ),       ...
                             Output_GetSegmentLocalRotationQuaternion.Rotation( 3 ),       ...
                             Output_GetSegmentLocalRotationQuaternion.Rotation( 4 ),       ...
                             Output_GetSegmentLocalRotationQuaternion.Occluded );

          % Get the local segment rotation in EulerXYZ co-ordinates
          Output_GetSegmentLocalRotationEulerXYZ = MyClient.GetSegmentLocalRotationEulerXYZ( SubjectName, SegmentName );
          fprintf( '        Local Rotation EulerXYZ: (%g,%g,%g) %d\n', ...
                             Output_GetSegmentLocalRotationEulerXYZ.Rotation( 1 ),       ...
                             Output_GetSegmentLocalRotationEulerXYZ.Rotation( 2 ),       ...
                             Output_GetSegmentLocalRotationEulerXYZ.Rotation( 3 ),       ...
                             Output_GetSegmentLocalRotationEulerXYZ.Occluded );

        Segment_List{Nb_Segment,1} = [SubjectName '.' SegmentName]; 
        Nb_Segment = Nb_Segment+1;
                  
        end% SegmentIndex

        % Count the number of markers
        MarkerCount = MyClient.GetMarkerCount( SubjectName ).MarkerCount;
        fprintf( '    Markers (%d):\n', MarkerCount );
        for MarkerIndex = 1:MarkerCount
          % Get the marker name
          MarkerName = MyClient.GetMarkerName( SubjectName, MarkerIndex ).MarkerName;

          % Get the marker parent
          MarkerParentName = MyClient.GetMarkerParentName( SubjectName, MarkerName ).SegmentName;

          % Get the global marker translation
          Output_GetMarkerGlobalTranslation = MyClient.GetMarkerGlobalTranslation( SubjectName, MarkerName );

          fprintf( '      Marker #%d: %s (%g,%g,%g) %d\n',                       ...
                             MarkerIndex,                                        ...
                             MarkerName,                                         ...
                             Output_GetMarkerGlobalTranslation.Translation( 1 ), ...
                             Output_GetMarkerGlobalTranslation.Translation( 2 ), ...
                             Output_GetMarkerGlobalTranslation.Translation( 3 ), ...
                             Output_GetMarkerGlobalTranslation.Occluded );
        end% MarkerIndex

      end% SubjectIndex

      % Get the unlabeled markers
      UnlabeledMarkerCount = MyClient.GetUnlabeledMarkerCount().MarkerCount;
      fprintf( '  Unlabeled Markers (%d):\n', UnlabeledMarkerCount );
      for UnlabeledMarkerIndex = 1:UnlabeledMarkerCount
        % Get the global marker translation
        Output_GetUnlabeledMarkerGlobalTranslation = MyClient.GetUnlabeledMarkerGlobalTranslation( UnlabeledMarkerIndex );
        fprintf( '    Marker #%d: (%g,%g,%g)\n',                                        ...
                           UnlabeledMarkerIndex,                                        ...
                           Output_GetUnlabeledMarkerGlobalTranslation.Translation( 1 ), ...
                           Output_GetUnlabeledMarkerGlobalTranslation.Translation( 2 ), ...
                           Output_GetUnlabeledMarkerGlobalTranslation.Translation( 3 ) );
      end% UnlabeledMarkerIndex

      % Count the number of devices
      DeviceCount = MyClient.GetDeviceCount().DeviceCount;
      fprintf( '  Devices (%d):\n', DeviceCount );
      for DeviceIndex = 1:DeviceCount
        fprintf( '    Device #%d:\n', DeviceIndex );

        % Get the device name and type
        Output_GetDeviceName = MyClient.GetDeviceName( DeviceIndex );
        fprintf( '      Name: %s\n', Output_GetDeviceName.DeviceName );
        fprintf( '      Type: %s\n', Output_GetDeviceName.DeviceType.ToString() );


        % Count the number of device outputs
        DeviceOutputCount = MyClient.GetDeviceOutputCount( Output_GetDeviceName.DeviceName ).DeviceOutputCount;
        fprintf( '      Device Outputs (%d):\n', DeviceOutputCount );
        for DeviceOutputIndex = 1:DeviceOutputCount
          % Get the device output name and unit
          Output_GetDeviceOutputName = MyClient.GetDeviceOutputName( Output_GetDeviceName.DeviceName, DeviceOutputIndex );

          % Get the device output value
          Output_GetDeviceOutputValue = MyClient.GetDeviceOutputValue( Output_GetDeviceName.DeviceName, Output_GetDeviceOutputName.DeviceOutputName );

          fprintf( '        Device Output #%d: %s %g %s %d\n',                       ...
                             DeviceOutputIndex,                                      ...
                             Output_GetDeviceOutputName.DeviceOutputName,            ...
                             Output_GetDeviceOutputValue.Value,                      ...
                             Output_GetDeviceOutputName.DeviceOutputUnit.ToString(), ...
                             Output_GetDeviceOutputValue.Occluded );
        end% DeviceOutputIndex

      end% DeviceIndex
    end
end
