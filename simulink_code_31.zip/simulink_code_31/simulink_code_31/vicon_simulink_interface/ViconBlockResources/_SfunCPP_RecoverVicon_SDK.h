/*
***************************************************************************
*
* Author: Augustin Manecy
*
* Copyright (C) 2011-2014 Augustin Manecy
*
* augustin.manecy@gmail.com
*
***************************************************************************
*
* This file is part of RT-MaG Toolbox.
*
*   RT-MaG Toolbox is free software: you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation, either version 3 of the License, or
*   (at your option) any later version.
*
*   RT-MaG Toolbox is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with RT-MaG Toolbox.  If not, see <http://www.gnu.org/licenses/>.
*
***************************************************************************
*
* This version of GPL is at https://www.gnu.org/licenses/gpl-3.0.txt
*
***************************************************************************
*/

#include "Client.h"
#include <iostream>

// ********************************************************
// Les librairies
// ********************************************************
#pragma comment(lib,"ViconDataStreamSDK_CPP.lib")

// NameSpace
using namespace ViconDataStreamSDK::CPP;
using namespace std;

// Object and segment properties
#define MAX_OBJECT              20
#define MAX_SEGMENT             20
#define MAX_MARKER              20
#define MAX_NAME_LENGTH         255
#define NB_OTHER_OUTPUTS        3       // New,framenumber and latency 
#define SEGMENT_LENGTH          7       // translation: 3, Euler: 3, occluded: 1              
#define MARKER_LENGTH           3

// Connection properties
#define MAX_CONNECTION_TRY      10
#define MAX_GETFRAME_TRY        3
#define TRANSMIT_MULTICAST      0
#define MULTICAST_ADDRESS       "139.124.59.0"

// Parameters order
#define VICON_IP_NUM_PARAM      0
#define VICON_PORT_NUM_PARAM    1
#define SAMPLE_TIME_NUM_PARAM   2
#define OBJECT_MAT_NUM_PARAM    3
#define MARKER_MAT_NUM_PARAM    4
#define OBJECT_NAME_NUM_PARAM   5
#define SEGMENT_NAME_NUM_PARAM  6
#define MARKER_NAME_NUM_PARAM   7

// ERROR_CODE
#define CONNECTION_FAILED   0x01
#define NOT_ENOUGH_OBJECT   0x02
#define MISSING_OBJECT      0x04
#define MISSING_SEGMENT 	0x08

/************** Declaration of function's protoypes **************/

void GetViconAddress(SimStruct *S, char* IP_Vicon_str, int* port);

void DisplayCompleteFrame(void);

// format adaptation
std::string AdaptDeviceType( const DeviceType::Enum i_DeviceType );
std::string AdaptUnit( const Unit::Enum i_Unit );
std::string AdaptOccluded( const bool i_Value );
std::string AdaptEnable( const bool i_Value );
std::string AdaptDirection( const Direction::Enum i_Direction );

/********** Declaration of data structure and new types **********/
typedef struct Segment
{
    std::string Name;
}Segment;

typedef struct Marker
{
    std::string Name;
}Marker;

typedef struct Object
{
    std::string Name;
    unsigned int Index;
    unsigned int NbSegment; 
    unsigned int NbMarker;
    Segment Segments[MAX_SEGMENT];
    Marker Markers[MAX_MARKER];
}Object;


