%%%%%%%%%%%%%%%%%%%%%%%%% Vicon_Connect.m %%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Vicon_Connect: Connect to the Vicon system via the MATLAB Vicon SDK.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Author: Augustin Manecy
%
% Copyright (C) 2011-2014 Augustin Manecy
%
% augustin.manecy@gmail.com
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This file is part of RT-MaG Toolbox.
%
%   RT-MaG Toolbox is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as published by
%   the Free Software Foundation, either version 3 of the License, or
%   (at your option) any later version.
%
%   RT-MaG Toolbox is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public License
%   along with RT-MaG Toolbox.  If not, see <http://www.gnu.org/licenses/>.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This version of GPL is at https://www.gnu.org/licenses/gpl-3.0.txt
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [MyClient, ConnectionError] = Vicon_Connect(HostName)

    % Load the SDK
    fprintf( 'Loading SDK...' );
    Client.LoadViconDataStreamSDK();
    fprintf( 'done\n' );

    % Program options
    HostName = '130.75.135.43:801';    % address of vicon computer

    % Make a new client
    MyClient = Client();

    % Connect to a server
    fprintf( 'Connecting to %s ...', HostName );
    Nb_Try = 1;
    while ((~MyClient.IsConnected().Connected) && (Nb_Try < 2))
        % Direct connection
        error = MyClient.Connect( HostName ).Result.Value;%JD: use this option
        Nb_Try = Nb_Try + 1;
        % Multicast connection
        %
        % MyClient.ConnectToMulticast('192.168.1.20', '224.0.0.0' );%JD: ???
    end
    fprintf( '\n' );

    if (~MyClient.IsConnected().Connected)
        % error message
        fprintf('Connection ERROR! \n') %   => Check that the IP is correct\n   => Check the remote computer is reachable\n   => Check that Tracker is turned on in remote computer\n\n
        ViconErrorDialog(error);

        % Unload the SDK
        fprintf( 'Unloading SDK...' );
        Client.UnloadViconDataStreamSDK();
        fprintf( 'done\n' );
        
        ConnectionError = 1;
    else
        ConnectionError = 0;
        % Enable some different data types
        fprintf('EnableSegmentData! \n')
        error = MyClient.EnableSegmentData().Result.Value;
        if error~=Result.Success
            ViconErrorDialog(error);
        end
        % MyClient.EnableMarkerData();
        % MyClient.EnableUnlabeledMarkerData();
        % MyClient.EnableDeviceData();

        fprintf( 'Segment Data Enabled: %d\n',          MyClient.IsSegmentDataEnabled().Enabled );
        fprintf( 'Marker Data Enabled: %d\n',           MyClient.IsMarkerDataEnabled().Enabled );
        fprintf( 'Unlabeled Marker Data Enabled: %d\n', MyClient.IsUnlabeledMarkerDataEnabled().Enabled );
        fprintf( 'Device Data Enabled: %d\n',           MyClient.IsDeviceDataEnabled().Enabled );

        % Set the streaming mode
        fprintf('SetStreamMode! \n')
        error = MyClient.SetStreamMode( StreamMode.ServerPush ).Result.Value;
        if error~=Result.Success
            ViconErrorDialog(error);
        end

        % Set the global up axis
        fprintf('SetAxisMapping! \n')
        error = MyClient.SetAxisMapping( Direction.Forward, ...
                                         Direction.Left,    ...
                                         Direction.Up ).Result.Value;    % Z-up
        if error~=Result.Success
            ViconErrorDialog(error);
        end


        Output_GetAxisMapping = MyClient.GetAxisMapping();
        fprintf( 'Axis Mapping: X-%s Y-%s Z-%s\n', Output_GetAxisMapping.XAxis.ToString(), ...
                                                   Output_GetAxisMapping.YAxis.ToString(), ...
                                                   Output_GetAxisMapping.ZAxis.ToString() );
        % Discover the version number
        Output_GetVersion = MyClient.GetVersion();
        fprintf( 'Version: %d.%d.%d\n', Output_GetVersion.Major, ...
                                        Output_GetVersion.Minor, ...
                                        Output_GetVersion.Point );

        % start the server transmission
        fprintf('StartTransmittingMulticast! \n')
        error = MyClient.StartTransmittingMulticast( '139.124.59.131', '255.255.255.255' ).Result.Value;%JD: adress of vicon computer, '255...255'=sends to all computers 
        if error~=Result.Success
            ViconErrorDialog(error);
        end
        
    end

end
