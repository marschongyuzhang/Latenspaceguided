function T_unity_vicon = calc_T_unity_vicon()
% Wand marker in nexus (L-frame)
m_center= [9.073, 8.9, 25.334]; % marker center [mm]
m_center_right= [-70.923, 9.05, 25.04];
m_center_left= [169.24, 8.708, 25.022];
m_center_down1= [8.793, 129.357, 24.74];
m_center_down2= [8.862, 249.198, 25.234];

X= [m_center_right', m_center_left', m_center_down1', m_center_down2'];

% Wand marker in Unity (expressed in right-hand system)
m_center_right= [0.08, 0, 0]; % [m]
m_center_left= [-0.16, 0, 0];
m_center_down1= [0, 0, 0.12];
m_center_down2= [0, 0, 0.24];
Y= (1e3)*[m_center_right', m_center_left', m_center_down1', m_center_down2']; % [mm]

% Calculate homogenous transformation
T_unity_vicon= esttransmat(X, Y);

isRotationMatrix(T_unity_vicon(1:3,1:3));
end


