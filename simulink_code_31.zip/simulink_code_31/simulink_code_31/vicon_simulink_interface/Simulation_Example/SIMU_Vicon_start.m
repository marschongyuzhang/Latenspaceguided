fs= 1000;
%open('SIMU_Vicon')

tic
sim('SIMU_Vicon', 'StopTime', '10');
toc