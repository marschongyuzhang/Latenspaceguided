function [ T ] = createthoraxcs( yJugular, yC7, yT8, yXihpoid, scale, varargin )
%CREATETHORAXCS establishes the thorax CS as represented by a homogeneous
%transofrm matrix with respect to the world CS (of the tracking system)
% World
%       T
%         thorax

if nargin <= 4
    scale = 1.0;
end

% positions in thorax CS
xJugular = [0, 0, 0]';
xC7 = [2.88, -110.70, 71.37]';
xT8 = [0.72, -167.35, -149.86]';
xXihpoid = [2.16, 56.65, -205.24]';
X = [xJugular, xC7, xT8, xXihpoid] * scale;

% positions in world CS
Y = [yJugular, yC7, yT8, yXihpoid];

T = esttransmat(X, Y);

end

