% convert transformation matrix to pose vector with quaternions
% 
% Input:
% T [4x4]
%   homogenous transformation matrix 
% 
% Output:
% x_quat [1x7]
%   pose
%   first cartesian position [1x3]
%   then quaternion orientation [1x4]. First xyz (rotation axis), then w
%   (angle) (ROS Order)

% Moritz Schappler, schappler@irt.uni-hannover.de, 2014-08
% (c) Institut für Regelungstechnik, Universität Hannover


function x_quat_ROS = tr2quat_ROS(T)

%% Init
%#codegen
assert(isa(T,'double') && isreal(T) && all(size(T) == [4 4]), ...
  'tr2quat_ROS: T = [4x4] double');

%% Calculation
xyz = T(1:3,4)';
[theta_, n_] = tr2angvec(T(1:3, 1:3));

quat = angvec2quat(theta_, n_);

x_quat_ROS = [xyz, quat(2:4), quat(1)];