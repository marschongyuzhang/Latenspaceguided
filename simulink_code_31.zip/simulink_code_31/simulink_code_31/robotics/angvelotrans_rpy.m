% Transformation zwischen Winkelgeschwindigkeit und Ableitung der
% Orientierungsdarstellung für RPY-Winkel (=XYZ-Euler-Winkel).
% 
% Eingabe:
% alpha, beta, gamma
%   Euler-Winkel für XYZ-Darstellung
% 
% Ausgabe:
% T
%   Transformationsmatrix (3x3) zwischen Winkelgeschwindigkeit im
%   Basiskoordinatensystem und den Zeitableitungen der
%   Rotationsdarstellungen (w = T*rpyD)
% 
% Source:
% [1] Natale 2003: Interaction Control of Robot Manipulators:
% Six-Degrees-of-Freedom Tasks 
% [2] Ortmaier: Robotik I Skript WS 2014/15
% [3] Corke: Robotics Toolbox

% Moritz Schappler, schappler@irt.uni-hannover.de, 2015-08
% (c) Institut für Regelungstechnik, Universität Hannover

function T = angvelotrans_rpy(alpha, beta, gamma)
%% Init
%#codegen
assert(isa(alpha,'double') && isreal(alpha) && all(size(alpha) == [1 1]), ...
      'angvelotrans_rpy: alpha = [1x1] double');  
assert(isa(beta,'double') && isreal(beta) && all(size(beta) == [1 1]), ...
      'angvelotrans_rpy: beta = [1x1] double');  
assert(isa(gamma,'double') && isreal(gamma) && all(size(gamma) == [1 1]), ...
      'angvelotrans_rpy: gamma = [1x1] double');  

%% Calculation
% Definition: [1], (2.34)
% Herleitung: [2], S.52, (4.23)
% Identische Implementierung: [3], rpy2jac
T = [1, 0,          sin(beta);
     0, cos(alpha), -sin(alpha)*cos(beta);
     0, sin(alpha), cos(alpha)*cos(beta)];

% Implementierung für andere Euler-Winkel: [3], eul2jac
