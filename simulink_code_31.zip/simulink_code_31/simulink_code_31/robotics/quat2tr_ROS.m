% convert pose vector with quaternions to transformation matrix
% 
% Input:
% x_quat [1x7]
%   pose
%   first cartesian position [1x3]
%   then quaternion orientation [1x4]. First xyz (rotation axis), then w
%   (angle) (ROS Order)
% 
% Output:
% T [4x4]
%   homogenous transformation matrix 

% Moritz Schappler, schappler@irt.uni-hannover.de, 2014-08
% (c) Institut für Regelungstechnik, Universität Hannover

function T = quat2tr_ROS(x_quat_ROS)

%% Init
%#codegen
assert(isa(x_quat_ROS,'double') && isreal(x_quat_ROS) && all(size(x_quat_ROS) == [1 7]));   

%% Calculation
% get displacement
xyz = x_quat_ROS(1:3);

% assemble quaternion (regard order: w, vx,vy,vz).
% This is NOT the ROS Message order
quat_ROS = x_quat_ROS(4:7);

% calculate transformation matrix
T = [quat2r_ROS(quat_ROS), xyz'; ...
        0 0 0          1];