% This function calculates the distances between links for a tree structured
% robot based on the vector of predecessors from the mdh notation of that robot.
% The distance is the number of joints between two links regardless of whether
% they are successors or not.

% Input:
% v_mdh [1xn double]
%   Vector of predecessors in mdh notation. Base index is 0, n is the number of
%   joints.
% Output:
% dist [mxm double]
%   Matrix containing the number of joints between each link, m is the number of
%   links

% Jonathan Vorndamme, jonathan.vorndamme@tum.de, 2018-11
% (c) Lehrstuhl fuer Robotik und Systemintelligenz, Technische Universitaet Muenchen

function dist = get_link_distances(v_mdh)
  num_links = length(v_mdh)+1;
  dist = NaN(num_links, num_links);
  max_cnt = floor(num_links/6+1);
  max_num = 1;
  for i=1:max_cnt
    max_num = max_num*(num_links-(i-1)*6);
  end
  for i=1:num_links
    dist_act = 0;
    dist(i,i) = 0;
    ind_dist = find(v_mdh == i-1);
    while ~isempty(ind_dist)
      dist_act = dist_act + 1;
      for j = ind_dist + 1
        dist(i, j) = dist_act;
      end
      ind_dist_old = ind_dist;
      ind_dist = find(any(v_mdh == ind_dist_old', 2));
    end
    ind_dist = find(isnan(dist(i,:)));
    for j = ind_dist
      dist(i, j) = dist(i, 1) + dist(j,1);
      for k = 1:num_links
        dist_tmp = dist(i, k) + dist(j,k);
        if dist_tmp < dist(i, j)
          dist(i, j) = dist_tmp;
        end
      end
    end
    for j = i:num_links
      dist(j, i) = dist(i, j);
    end
  end
end