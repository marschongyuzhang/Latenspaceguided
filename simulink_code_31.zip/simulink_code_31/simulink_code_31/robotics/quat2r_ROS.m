% Convert Quaternion Rotation Representation to Rotation Matrix
% 
% Input:
% quat [1x7]
%   Quaternion Orientation:
%   First xyz (rotation axis), then w (angle) (ROS order)
% 
% Output:
% R [3x3]
%   rotation matrix 
% 
% Sources:
% [1] Tobias Ortmeier: Robotik I Vorlesungsskript
% [2] http://en.wikipedia.org/wiki/Quaternions_and_spatial_rotation#Conversion_to_and_from_the_matrix_representation

% Moritz Schappler, schappler@irt.uni-hannover.de, 2014-08
% (c) Institut für Regelungstechnik, Universität Hannover

function R = quat2r_ROS(quat_ROS)
%% Init
%#codegen
assert(isa(quat_ROS,'double') && isreal(quat_ROS) && all(size(quat_ROS) == [1 4]), ...
      'quat2r_ROS: R = [3x3] double');

%% Calculation
quat = quat_ROS([4, 1:3]);
R = quat2r(quat);