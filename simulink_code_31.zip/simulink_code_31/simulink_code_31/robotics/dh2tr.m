% Transformationsmatrix aus Denavit-Hartenberg-Parametern berechnen
% 
% Quelle: Robotics Toolbox (Peter Corke)

% Moritz Schappler, schappler@irt.uni-hannover.de, 2014-07
% (c) Institut für Regelungstechnik, Universität Hannover

function T = dh2tr(q,d,a,alpha)

sa = sin(alpha); ca = cos(alpha);
st = sin(q); ct = cos(q);

T =    [    ct  -st*ca  st*sa   a*ct
    st  ct*ca   -ct*sa  a*st
    0   sa      ca      d
    0   0       0       1];