% convert rotation matrix to quaternion in ROS convention
% 
% Input:
% R [3x3]
%   rotation matrix
% 
% quat [1x4]
%   quaternion in ROS convention: First xyz (rotation axis), then w (angle)

% Moritz Schappler, schappler@irt.uni-hannover.de, 2014-08
% (c) Institut für Regelungstechnik, Universität Hannover

function quat_ROS = r2quat_ROS(R)

%% Init
%#codegen
assert(isa(R,'double') && isreal(R) && all(size(R) == [3 3]));  

%% Calculation
quat = r2quat(R);

quat_ROS = quat([4,1:3]);