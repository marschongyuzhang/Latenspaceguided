% This function recursively finds all possibly solvable contact combinations for
% a robot using the list of predecessors from the mdh parameters and a link
% distance matrix. At most one contact per link is assumed.

% Input:
% v_mdh [1xn double]
%   Vector of predecessors in mdh notation. Base index is 0, n is the number of
%   joints.
% minimal_test_set [1x1 double] (optional)
%   A positiv value result in listing a minimal set of combinations where every
%   solvable combination that exists is part of one of those combinations. A 0
%   value results in a set of combinations where later sets can be part of
%   prevoious sets due to the search method. A negative value results in
%   generating all possible contact combinations. Default value is zero.
% dist [mxm double] (optional)
%   Matrix containing the number of joints between each link, m is the number of
%   links. If not given, it is generated from v_mdh.
% reulst_size [1x2 double] (optional)
%   Defines the size of the result array. Should be at least [k l] to avoid
%   unnecessary memory allocations. If not given, it is estimated from v_mdh.
% Output:
% combs [kxl double]
%   Matrix with solvable contact combinations. Each line holds one combination
%   followed by NaNs. Subcombinations of other combinations are not included
%   in the list. k is the number of solvable combinations for the robot, l is
%   the maximum number of contacts in a solvable contact combination. Both
%   numbers might be superseeded by the correponding  inputs size, if bigger.
% cnt_cmb [double]
%   Number of sovlable contact_combinations

% Jonathan Vorndamme, jonathan.vorndamme@tum.de, 2018-09
% (c) Lehrstuhl fuer Robotik und Systemintelligenz, Technische Universitaet Muenchen

function [combs, cnt_cmb] = find_all_solvable_contact_combinations(v_mdh,...
                                            minimal_test_set, dist, result_size)
  if nargin==1
    minimal_test_set = 0;
  end
  if nargin<=2
    dist = get_link_distances(v_mdh);
    max_cnt = floor(length(v_mdh)/6+1);
    max_num = 1;
    for i=1:max_cnt
      max_num = max_num*(length(v_mdh)-(i-1)*6+1);
    end
    result_size = [max_num, max_cnt];
  end
  comb = NaN(1, result_size(2));
  cnt_cmb = 1;
  cnt_el = 1;
  candidates = ones(length(v_mdh)+1, 1);
  act_jnts = zeros(length(v_mdh), 1);
  combs = NaN(result_size);
  [combs, cnt_cmb] = find_contact_combinations_recursive(comb, cnt_cmb,...
                         cnt_el, candidates, act_jnts, v_mdh, dist, combs,...
                         minimal_test_set);
  cnt_cmb = cnt_cmb - 1;
  combs = combs(1:cnt_cmb,:);
  if minimal_test_set>0
    valid = ones(cnt_cmb,1);
    for i=cnt_cmb:-1:1
      for j=1:i-1
        if all(ismember(combs(i,~isnan(combs(i,:))),combs(j,:)))
          valid(i) = 0;
        end
      end
    end
    combs = combs(find(valid),:); %#ok<FNDSB>
    cnt_cmb = sum(valid);
  end
end

function [combs, cnt_cmb] = find_contact_combinations_recursive(comb,...
                                cnt_cmb, cnt_el, candidates, act_jnts, v_mdh,...
                                dist, combs, minimal_test_set)
  list_nextl = find(candidates);
  if isempty(list_nextl)
    if analyse_contact_combination_solvability(comb, v_mdh)
      combs(cnt_cmb, :) = comb;
      cnt_cmb = cnt_cmb + 1;
    end
    return;
  end
  comb_found = false;
  for i=list_nextl'
    lnk = i;
    act_jnts_tmp = act_jnts;
    while (lnk~=1 && ~act_jnts(lnk-1))
      act_jnts_tmp(lnk-1) = 1;
      lnk = v_mdh(lnk-1) + 1;
    end
    if sum(act_jnts_tmp)+6>=(sum(~isnan(comb))+1)*6
      comb_found = true;
      comb(cnt_el) = i;
      [combs, cnt_cmb] = find_contact_combinations_recursive(comb, cnt_cmb,...
                             cnt_el+1, candidates & dist(i,:)'>=6 &...
                             (1:length(candidates))'>i, act_jnts_tmp, v_mdh,...
                             dist, combs, minimal_test_set);
      comb(cnt_el) = NaN;
    end
  end
  if ~comb_found || (minimal_test_set<0 && ~isnan(comb(1)))
    if analyse_contact_combination_solvability(comb, v_mdh)
      combs(cnt_cmb, :) = comb;
      cnt_cmb = cnt_cmb + 1;
    end
    return;
  end
end