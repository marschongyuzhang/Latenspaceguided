% This function analyses the solvability of a contact isolation/identification
% problem for a robot with a number of contacts at different links in a
% non-singular pose based on joint torque sensing and external base wrench
% estimation. Please keep in mind, that the robot pose has to have no
% singularity regardless of the chosen base.

% Input:
% comb [mx1 double]
%   the numbers of the links, at which the contacts occur. The numbers can be
%   followed by NaNs which are ignored. They cannot be the same and m is an
%   arbitrary number.
% v_mdh [nx1 double]
%   the vector of predecessors for every link in mdh notation. Base is indexed
%   zero, n is the number of joints/links without base
% Output:
% result [1x1 bool]
%   true if problem is solvable

% Jonathan Vorndamme, jonathan.vorndamme@tum.de, 2018-09
% (c) Lehrstuhl fuer Robotik und Systemintelligenz, Technische Universitaet Muenchen

function result = analyse_contact_combination_solvability(comb, v_mdh)
  result = true;
  involved_contacts = zeros(1, length(v_mdh)+1);
  information_at_link = zeros(1, length(v_mdh)+1);
  joint_active = zeros(1, length(v_mdh));
  for i=1:length(comb)
    if isnan(comb(i))
      break;
    else
      lnk = comb(i);
      info = 0;
      while lnk~=1
        involved_contacts(lnk) = involved_contacts(lnk) + 1;
        information_at_link(lnk) = information_at_link(lnk) + info;
        if joint_active(lnk-1) == 0 && info < 6
          info = info + 1;
          joint_active(lnk-1) = 1;
        end
        lnk = v_mdh(lnk-1) + 1;
      end
      involved_contacts(1) = involved_contacts(1) + 1;
      information_at_link(1) = information_at_link(1) + info;
    end
  end
  for i=1:length(involved_contacts)
    if information_at_link(i) < 6*(involved_contacts(i)-1)
      result = false;
      break;
    end
  end
end