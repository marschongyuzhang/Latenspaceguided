function [ T ] = esttransmat( X, Y )
%ESTTRANSMAT estimates a homogeneous transformation matrix from two point
%clouds which are expressed in different frames of reference.
%   Input X, Y are the point clouds, whose columns represent each single
%   point.
%   Output T the homogeneous transformation matrix that 
%   [y; 1] = T * [x; 1]

% Reference:
% T. Ortmeier: Computer- und Roboterassistierte Chirugie -- Registrierung

cntPt1 = size(X, 2);
cntPt2 = size(Y, 2);
if cntPt1 ~= cntPt2
    error('Point clouds must be in the same size.');
end

% Centering
x0 = mean(X, 2);
y0 = mean(Y, 2);

H = (X(:,1)-x0)*(Y(:,1)-y0)';
for I = 2:cntPt1
    H = H + (X(:,I)-x0)*(Y(:,I)-y0)';
end

% Singular value decomposition
[U, S, V] = svd(H); % H = U*S*V'

% Rotation matrix
%     {Y}
%         R
%           {X}
D = diag([1, 1, det(V*U')]);
R = V*D*U';

% Translation
t = y0 - R*x0;

% Transformation
%     {Y}
%         T
%           {X}
T = [R, t; 0, 0, 0, 1];


end

