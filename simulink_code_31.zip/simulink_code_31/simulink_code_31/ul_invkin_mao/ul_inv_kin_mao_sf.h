/*
* Generated S-function Target for model ul_inv_kin_mao. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Tue May  9 19:22:34 2023
*/

#ifndef RTWSFCN_ul_inv_kin_mao_sf_H
#define RTWSFCN_ul_inv_kin_mao_sf_H

#include "ul_inv_kin_mao_sfcn_rtw\ul_inv_kin_mao_sf.h"
  #include "ul_inv_kin_mao_sfcn_rtw\ul_inv_kin_mao_sf_private.h"

#endif
