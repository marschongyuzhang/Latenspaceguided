/*
 * Generated S-function Target for model ul_inv_kin_mao. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Tue May  9 19:22:34 2023
 */

#include "ul_inv_kin_mao_sf.h"
#include "ul_inv_kin_mao_sfcn_rtw\ul_inv_kin_mao_sf.c"
#include "ul_inv_kin_mao_sfcn_rtw\ul_inv_kin_mao_sf_data.c"


